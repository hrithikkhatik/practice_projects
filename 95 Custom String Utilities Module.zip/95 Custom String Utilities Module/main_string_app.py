import string_utils
print(string_utils.reverse_string("Hello Python"))

print(string_utils.is_palindrome("Hello Python"))

print(string_utils.count_words("Hello Python"))

print(string_utils.reverse_string("Madam"))

print(string_utils.is_palindrome("Madam"))

print(string_utils.count_words("Madam"))


