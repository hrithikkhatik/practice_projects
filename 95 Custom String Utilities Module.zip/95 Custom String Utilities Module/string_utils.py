def reverse_string(s):
    return s[::-1]

def is_palindrome(s):
    rev = s[::-1]
    if rev.lower() == s.lower():
        return True
    else:
        return False

def count_words(s):
    return len(s)

